    $(document).ready(function() {
    $('.sure').click(function(){
        alert(1);
        queType = $('#queType').val();
        testType = $('#testType').val();
        if (queType == 0) action = 'indexSel';
        else if (queType == 1) action = 'indexJud';
        else if (queType == 2) action = 'indexAns';
        window.open('/questions/'+action+'/'+testType, '_blank');
    });
});