
    if (document.getElementById('__sunsetKGR')==null)
{var _head = document.getElementsByTagName('head')[0];var _link = document.createElement('link'); _link.id = '__sunsetKGR';_link.rel='stylesheet'; _link.href='../../../../../KoolPHPSuite/KoolControls/KoolGrid/styles/sunset/sunset.css';_head.appendChild(_link);}