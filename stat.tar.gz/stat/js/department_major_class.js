$(function() {
    $('.add_button').click(function (){
        return confirm('您确定要添加吗?');
    });
    $('.delete_button').click(function(){
        return confirm('您确定要删除吗?');
    });
    $('.combine_button').click(function(){
        return confirm('您确定要合并吗?');
    });
    $('.department_delete_button').click(function(){
        return confirm('删除该院系同样会删除与该院系有关的一切,您确定要删除该院系吗?');
    });
    $('.department_combine_button').click(function(){
        return confirm('该操作也同样会合并与该院系有关的一切,您确定要合并吗?');
    });
});
