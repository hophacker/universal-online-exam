#!/bin/bash
vim -p 
#fengjie
#fengjie
#fuck
#zhu
#fengjie