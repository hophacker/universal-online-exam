#!/bin/bash 
./translation.sh -c   "UOES" "UOES"
