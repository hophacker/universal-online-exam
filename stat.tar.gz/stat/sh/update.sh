#!/bin/bash
cd ~/NetBeansProjects/yangda/
svn update  app/View/ 
#app/Controller/ app/Model/ WebRoot/ app/webroot/ class/
