git clone https://github.com/cakephp/debug_kit app/Plugin/DebugKit
cp tmp app/tmp -R
chmod 777 app/tmp -R
