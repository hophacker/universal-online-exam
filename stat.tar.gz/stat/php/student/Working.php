<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!Doctype html><html xmlns=http://www.w3.org/1999/xhtml>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Frameset Example Title (Replace this section with your own title)</title>
        <script type='text/javascript' src='../jquery-ui/js/jquery-1.9.1.js'></script>
        <style type="text/css">
            
        </style>
        <script>
            
        </script>
    </head>
    
    <body>
        <h2>本功能正在积极开发中，敬请期待....</h2>
    </body>
    
</html>