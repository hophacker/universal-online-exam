<?php
    class Cat {
    }

class Hypnotic_Cat extends Cat {
    // Constructor
    function Hypnotic_Cat() {
    }

    // This function must be called statically
    public static function hypnotize() {

echo ("The cat was hypnotized.");
      return;
    }
}

// Hypnotize all cats
Hypnotic_Cat::hypnotize();


$hypnotic_cat = new Hypnotic_Cat();
// Does nothing
$hypnotic_cat->hypnotize();
?>
