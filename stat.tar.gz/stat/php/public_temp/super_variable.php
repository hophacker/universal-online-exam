<?php
foreach ($_SERVER as $var=>$value){
	echo "$var => $value <br/>";
}
?>
