<html>
	<head>
		<title>Hello World</title>
	</head>
	<body>
		<?php
			print "hello world!<br/>";
			print "Goodbye.<br/>";
			print "Over and out.";
			phpinfo(); 
		?>
	</body>
</html>
