<?php
	include('function_capitalize.php');
	include_once('function_capitalize.php');
	$s="fengjie";
	capitalize($s);
	echo $s;
?>
