<?php
include_once '../sys/core/init.inc.php';

echo htmlentities('fenjige;"\';');
$cal = new Calendar($dbo, "2010-01-01 12:00:00");
if (is_object($cal))
{
	echo "<pre>", var_dump($cal),  "</pre>";
}
$id = "fengjie";
echo "`id`";
echo " = :uame $id";
