<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Information
 *
 * @author john
 */
class Information extends AppModel{
    //put your code here
    
}

?>
