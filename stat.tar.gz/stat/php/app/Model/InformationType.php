<?php

class InformationType extends AppModel {
}