<?php
require_once('../private/class/autoload.inc');
$smt = new SMT('Login');
$smt->render();
?>