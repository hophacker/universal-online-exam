<?php
$DB_HOST = '58.211.23.247';
$DB_USER = 'system';
$DB_PASS = 'system';
$DB_SCHEMA = 'dxks';
?>
