<?php
function JPOST($key, $default=0){
    return isset($_POST[$key])? ($_POST[$key]==""? $default:$_POST[$key]) : $default;
}
function JPOSTS($key, $default="\"\""){
    return isset($_POST[$key])? ($_POST[$key]==""? $default:$_POST[$key]) : $default;
}
function JGET($key, $default=0){
    return isset($_GET[$key])? ($_GET[$key]==""? $default:$_GET[$key]) : $default;
}
function JGETS($key, $default="\"\""){
    return isset($_GET[$key])? ($_GET[$key]==""? $default:$_GET[$key]) : $default;
}
?>
