= _$SESSION['Student']
Manager
array(
	'Student' => array(
		'id' => '17063',
		's_user' => '000000',
		's_num' => '100015106',
		's_pwd' => 'c4ca4238a0b923820dcc509a6f75849b',
		's_name' => '戴碧星',
		's_class' => '会计33班',
		's_mail' => '814024962@qq.com',
		'score_1' => '72',
		'score_2' => '-1',
		'score_3' => '-1',
		'score_ans' => '-1',
		'score_type' => '-1',
		'end_sec' => '-1',
		'state' => '1',
		's_date' => '1991-03-14',
		's_role' => '6',
		'class_id' => '409',
		'reg_date' => '2001-11-13',
		'edu_id' => '1',
		'last_login' => null,
		's_phone' => null,
		's_grade' => null,
		'read_message_id' => ',15,14,12,14,13,',
		'has_test' => null,
		'test_type_id' => null
	),
	'Class' => array(
		'id' => '409',
		'class_name' => '土木80902',
		'enrol_year' => null,
		'class_type' => '1',
		'major_id' => '76',
		'state' => '1',
		'total_students' => '48'
	),
	'Major' => array(
		'id' => '76',
		'major_name' => '土木工程（建筑工程）',
		'department_id' => '12',
		'state' => '1'
	),
	'Department' => array(
		'id' => '12',
		'dept_name' => '广陵学院',
		'paper_id' => '-1',
		'state' => '1'
	)
)
> array('name', 'email'),
  'order' => 'field3 DESC',
  'recursive' => 2,
  'group' => 'type',
  'callbacks' => false,
));


 = _$SESSION['Student']
Manager
array(
	'Student' => array(
		'id' => '17063',
		's_user' => '000000',
		's_num' => '100015106',
		's_pwd' => 'c4ca4238a0b923820dcc509a6f75849b',
		's_name' => '戴碧星',
		's_class' => '会计33班',
		's_mail' => '814024962@qq.com',
		'score_1' => '72',
		'score_2' => '-1',
		'score_3' => '-1',
		'score_ans' => '-1',
		'score_type' => '-1',
		'end_sec' => '-1',
		'state' => '1',
		's_date' => '1991-03-14',
		's_role' => '6',
		'class_id' => '409',
		'reg_date' => '2001-11-13',
		'edu_id' => '1',
		'last_login' => null,
		's_phone' => null,
		's_grade' => null,
		'read_message_id' => ',15,14,12,14,13,',
		'has_test' => null,
		'test_type_id' => null
	),
	'Class' => array(
		'id' => '409',
		'class_name' => '土木80902',
		'enrol_year' => null,
		'class_type' => '1',
		'major_id' => '76',
		'state' => '1',
		'total_students' => '48'
	),
	'Major' => array(
		'id' => '76',
		'major_name' => '土木工程（建筑工程）',
		'department_id' => '12',
		'state' => '1'
	),
	'Department' => array(
		'id' => '12',
		'dept_name' => '广陵学院',
		'paper_id' => '-1',
		'state' => '1'
	)
)
