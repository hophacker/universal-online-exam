<?php
class ErrorsController extends AppController {
    public function loginOutOfdate(){
        
    }
    public function index(){
        
    }
}
