<?php
session_start( );
?>
<html>
<head>
<title>Using a session variable</title>
</head>
<body>

<br />
<?php
$docRoot = getenv("DOCUMENT_ROOT");

print $docRoot;
?>
</body>
</html>