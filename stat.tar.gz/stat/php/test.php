<?php
require_once('../private/class/SMT.php');
$smt = new SMT('test');
$smt->render(array(
    'title' => '考试页面'
    ));
?>
